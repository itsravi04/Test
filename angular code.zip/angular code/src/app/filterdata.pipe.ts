import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterdata'
})
export class FilterdataPipe implements PipeTransform {
  transform(value: any, filterByName: string, filterBytitle: string, filterStartDate:string, filterEndDate:string, filterAge:string): any {
    if(value.length === 0){
      return value
   }
   return value?.filter(function(search){
       return search.name.toLowerCase().indexOf(filterByName.toLowerCase()) > -1 &&
               search.title.toLowerCase().indexOf(filterBytitle.toLowerCase()) > -1 &&
               search.age >= filterAge &&
               search.startDate >= filterStartDate &&
               search.endDate >= filterEndDate;
    })
  
  }

}