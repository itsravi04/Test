import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.scss']
})
export class EmployeelistComponent implements OnInit {

  public employeeForm!: FormGroup;
  public listItem= [];
  public isDisabled: boolean = false;
  public editEnable: boolean = false;
  public today = new Date();
  public counter:number = 1;
  public popEnable:boolean = false;
  private empDetails;
  private count: number;
  public filterName: string = '';
  public filtertitle: string = '';
  public filterStart = '';
  public filterEnd = '';
  public filterAge ='';
  private finalMonth: string;
  private currentMonth: any;
  private currentDay: number;
  private finalDay: string;
  public dateFormat: string;

  
  constructor(private fb: FormBuilder, private datePipe: DatePipe,){
    this.currentMonth= this.today.getMonth() + 1;
    if(this.currentMonth < 10){
       this.finalMonth = '0' + this.currentMonth;
    }
    else{
      this.finalMonth = this.currentMonth;
    }
    this.currentDay = this.today.getDay()+2;
     if(this.currentDay < 10){
         this.finalDay = '0' + this.currentDay;
     }
     else{
         this.currentDay
     }
      this.dateFormat = this.today.getFullYear() + "-" + this.finalMonth + "-" + this.finalDay;
  }

  ngOnInit(): void {
   this.employeeDetails();
  }

 private employeeDetails(): any{
    this.employeeForm = this.fb.group({
        employeeID: [''],
        name: ['', Validators.required],  
        title: ['', Validators.required],  
        age: ['', Validators.required],  
        startDate: ['', Validators.required],  
        endDate: ['', Validators.required],  
    })
  }

  public editDetail(){
      this.employeeForm.reset();
      this.editEnable = true;
  }

  public isSave(){
    if(this.employeeForm.invalid){
        this.employeeForm.markAllAsTouched();
        return;
      }
      this.employeeForm.patchValue({
          employeeID: this.counter,
      })
      this.count = this.counter++
     this.listItem.push(this.employeeForm.value);
     this.employeeForm.reset();
     this.editEnable = false;
     if(this.listItem.length == 1){
      this.isDisabled = true;
    }
    else{
       this.isDisabled = false;
    }
    
  }

  public removeItem(ele){ 
    if(this.listItem.length == 2){
        this.isDisabled = true;
      }
     this.listItem.forEach((value, index) => {
        if(value === ele){
             this.listItem.splice(index, 1)
            }
     });
   
  }
 
  // view employee info

  public editInfo(id){
    this.empDetails = this.listItem.find((emp)=>{
        return emp.employeeID === id;
    });
    this.employeeForm = this.fb.group({
      employeeID: this.count,
      name: new FormControl(this.empDetails.name),
      title: new FormControl(this.empDetails.title),  
      age: new FormControl(this.empDetails.age),
      startDate: new FormControl(this.empDetails.startDate),
      endDate: new FormControl(this.empDetails.endDate), 
    });
  }

  // update employee info

  public updaeEmpInfo(){
     this.employeeForm.setValue({
      employeeID: this.count,
      name: this.employeeForm.value.name,
      title: this.employeeForm.value.title,  
      age: this.employeeForm.value.age,
      startDate: this.employeeForm.value.startDate,
      endDate: this.employeeForm.value.endDate, 
     });
     alert('Data updaed succesfully')
     this.popEnable = false;
  }


}
